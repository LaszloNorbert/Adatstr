//
// Created by user on 24/02/2021.
//
#ifndef INC_2_HET_HEADER_H
#define INC_2_HET_HEADER_H

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

void Print(int);
int FindInArray(int*, int, int, int *);
int* GenerateArray(int);
int binarySearch(int*, int, int, int, int*);
int CmpFunc (const void *, const void *);

#endif //INC_2_HET_HEADER_H
