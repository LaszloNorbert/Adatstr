//
// Created by user on 25/02/2021.
//

#ifndef INC_2_HETADATSTR_HEADER2_H
#define INC_2_HETADATSTR_HEADER2_H

#include <stdlib.h>
#include <time.h>
#include <stdio.h>

void Feladat6Func(int, int, int, int, int);
void Feladat7Func(int, int, int, int, int);
double Feladat4Func(int);
void Feladat3Func();


#endif //INC_2_HETADATSTR_HEADER2_H
