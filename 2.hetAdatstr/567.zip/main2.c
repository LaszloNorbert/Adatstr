#include "header2.h"

int main() {
    int i=10, j=5, k=3, n=20, noOfRuns;
    scanf("%d", &noOfRuns);
    printf("Feladat 6:\n");
    Feladat6Func(i,j, k, n, noOfRuns);
    printf("Feladat 7:\n");
    Feladat7Func(i, j, k, n, noOfRuns);
    return 0;
}
